from setuptools import setup

setup(name='pypresence',
      author='qwertyquerty',
      url='https://github.com/qwertyquerty/pypresence',
      version='1.0',
      packages=['pypresence'],
      license='MIT',
      description='Discord RPC client written in python'
)
